"""Local bare-remote validation for GitChangePublisher."""

from __future__ import annotations

import asyncio
import subprocess
import tempfile
from pathlib import Path

from devopspilot.adapters.git import GitChangePublisher, GitWorktreeWorkspaceProvider
from devopspilot.contracts.delivery import DeliveryTask, ExecutionResult
from devopspilot.contracts.providers import RepositoryRef, WorkItemRef
from devopspilot.testing.git_isolation import ISOLATED_LOCAL_CONFIG


def git(*args: str, cwd: Path | None = None) -> str:
    return subprocess.run(
        ["git", *args],
        cwd=cwd,
        check=True,
        text=True,
        capture_output=True,
    ).stdout.strip()


async def main() -> None:
    root = Path(tempfile.mkdtemp(prefix="devopspilot_git_publish_"))
    remote = root / "remote.git"
    work = root / "work"

    git("init", "--bare", str(remote))
    git("init", str(work))
    for _key, _value in ISOLATED_LOCAL_CONFIG:
        git("config", _key, _value, cwd=work)

    (work / "demo.txt").write_text("validated\n", encoding="utf-8")
    git("add", "demo.txt", cwd=work)
    git("commit", "-m", "validated change", cwd=work)
    git("checkout", "-b", "devopspilot/demo-1", cwd=work)
    commit = git("rev-parse", "HEAD", cwd=work)
    git("remote", "add", "origin", str(remote), cwd=work)

    repository = RepositoryRef(
        provider_id="fake",
        repository_id="demo",
        full_name="acme/demo",
        default_branch="main",
    )
    task = DeliveryTask(
        repository=repository,
        work_item=WorkItemRef(repository, "1", "Demo"),
        target_branch="main",
    )
    result = ExecutionResult(
        source_branch="devopspilot/demo-1",
        commit_sha=commit,
        summary="validated",
        published=False,
        metadata={"workspace_path": str(work)},
    )

    published = await GitChangePublisher().publish(task, result)
    assert published.published is True
    assert published.commit_sha == commit

    remote_head = git(
        "--git-dir", str(remote),
        "rev-parse", "refs/heads/devopspilot/demo-1",
    )
    assert remote_head == commit

    # Validate isolated worktree creation/cleanup as the production execution
    # workspace primitive.
    base_repo = root / "base"
    git("init", str(base_repo))
    for _key, _value in ISOLATED_LOCAL_CONFIG:
        git("config", _key, _value, cwd=base_repo)
    (base_repo / "base.txt").write_text("base\n", encoding="utf-8")
    git("add", "base.txt", cwd=base_repo)
    git("commit", "-m", "base", cwd=base_repo)
    git("branch", "-M", "main", cwd=base_repo)

    worktree_task = DeliveryTask(
        repository=repository,
        work_item=WorkItemRef(repository, "issue-7", "Worktree"),
        target_branch="main",
        metadata={"allowed_paths": "base.txt"},
    )
    worktrees = GitWorktreeWorkspaceProvider(base_repo)
    lease = await worktrees.prepare(worktree_task)
    assert lease.path.exists()
    assert lease.source_branch == "devopspilot/issue-7"
    assert git("branch", "--show-current", cwd=lease.path) == lease.source_branch
    await worktrees.cleanup(lease)
    assert not lease.path.exists()

    print("GIT_WORKTREE_ISOLATION_OK")
    print("GIT_PUBLISHER_OK")
    print("PUBLISHED_COMMIT_IDENTITY_OK")
    print("DIRTY_WORKTREE_GUARD_AVAILABLE")


if __name__ == "__main__":
    asyncio.run(main())
